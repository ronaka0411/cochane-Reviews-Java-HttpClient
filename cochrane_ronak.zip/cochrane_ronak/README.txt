Run this commands in Command Line:

For Windows:
Compilation:
javac -cp ".;httpclient-4.5.6.jar;httpcore-4.4.10.jar" ExtractLoadReview.java

Run:
java -cp ".;httpclient-4.5.6.jar;httpcore-4.4.10.jar" ExtractLoadReview


For Linux:
Compilation:
javac -cp ".:httpclient-4.5.6.jar:httpcore-4.4.10.jar" ExtractLoadReview.java

Run:
java -cp ".:httpclient-4.5.6.jar:httpcore-4.4.10.jar" ExtractLoadReview

